param($UPN)
Get-MgUser -UserId $UPN | Select AccountEnabled