param($Name)
Get-MgUser -Filter "startswith(DisplayName,'$Name')"