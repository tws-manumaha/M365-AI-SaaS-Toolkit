param($Name,$UPN,$Password)
New-MgUser -DisplayName $Name -UserPrincipalName $UPN -MailNickname ($UPN.Split("@")[0]) -AccountEnabled:$true -PasswordProfile @{Password=$Password}