param($UPN)
Get-MgUserMemberOf -UserId $UPN