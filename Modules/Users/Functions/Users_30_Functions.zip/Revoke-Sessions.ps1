param($UPN)
Invoke-MgInvalidateUserRefreshToken -UserId $UPN