param($FilePath)
$users=Get-Content $FilePath
foreach($u in $users){try{Remove-MgUser -UserId $u; Write-Host "SUCCESS: $u"}catch{Write-Host "FAILED: $u"}}