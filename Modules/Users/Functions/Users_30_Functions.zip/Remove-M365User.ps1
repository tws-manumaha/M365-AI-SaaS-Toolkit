param($UPN)
Remove-MgUser -UserId $UPN