param($UPN)
Update-MgUser -UserId $UPN -AccountEnabled:$true