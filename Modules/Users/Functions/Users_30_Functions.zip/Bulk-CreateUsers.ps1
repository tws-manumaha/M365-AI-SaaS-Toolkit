param($FilePath)
$users=Import-Csv $FilePath
foreach($u in $users){New-MgUser -DisplayName $u.Name -UserPrincipalName $u.UPN -MailNickname ($u.UPN.Split("@")[0]) -AccountEnabled:$true -PasswordProfile @{Password=$u.Password}}