param($UPN)
Get-MgUser -UserId $UPN