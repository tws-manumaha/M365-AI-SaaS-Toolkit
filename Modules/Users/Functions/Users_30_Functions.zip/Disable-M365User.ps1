param($UPN)
Update-MgUser -UserId $UPN -AccountEnabled:$false