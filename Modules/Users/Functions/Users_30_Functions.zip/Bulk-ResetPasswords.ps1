param($FilePath)
$users=Get-Content $FilePath
foreach($u in $users){try{Update-MgUser -UserId $u -PasswordProfile @{Password="Temp@123"}; Write-Host "SUCCESS: $u"}catch{Write-Host "FAILED: $u"}}