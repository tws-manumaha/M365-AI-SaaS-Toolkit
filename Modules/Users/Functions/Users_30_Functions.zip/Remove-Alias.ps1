param($UPN,$Alias)
Set-Mailbox $UPN -EmailAddresses @{Remove=$Alias}