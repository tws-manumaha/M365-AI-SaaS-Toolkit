param($UPN)
Update-MgUser -UserId $UPN -PasswordProfile @{Password="Temp@123"}