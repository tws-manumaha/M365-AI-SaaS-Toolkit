param($UPN)
Get-MgUserManager -UserId $UPN