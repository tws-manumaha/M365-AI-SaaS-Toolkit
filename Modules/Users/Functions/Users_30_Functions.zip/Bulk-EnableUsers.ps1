param($FilePath)
$users=Get-Content $FilePath
foreach($u in $users){try{Update-MgUser -UserId $u -AccountEnabled:$true; Write-Host "SUCCESS: $u"}catch{Write-Host "FAILED: $u"}}