param($UPN)
Update-MgUser -UserId $UPN -PasswordProfile @{ForceChangePasswordNextSignIn=$true}