param($UPN,$Title)
Update-MgUser -UserId $UPN -JobTitle $Title