param($UPN)
Get-MgUserLicenseDetail -UserId $UPN