param($UPN,$SkuId)
Set-MgUserLicense -UserId $UPN -AddLicenses @() -RemoveLicenses @($SkuId)