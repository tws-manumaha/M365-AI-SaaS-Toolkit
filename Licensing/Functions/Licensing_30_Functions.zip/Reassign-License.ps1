param($UPN,$OldSku,$NewSku)
Set-MgUserLicense -UserId $UPN -AddLicenses @() -RemoveLicenses @($OldSku); Set-MgUserLicense -UserId $UPN -AddLicenses @{SkuId=$NewSku} -RemoveLicenses @()