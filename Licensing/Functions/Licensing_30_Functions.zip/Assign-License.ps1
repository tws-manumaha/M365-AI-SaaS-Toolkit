param($UPN,$SkuId)
Set-MgUserLicense -UserId $UPN -AddLicenses @{SkuId=$SkuId} -RemoveLicenses @()