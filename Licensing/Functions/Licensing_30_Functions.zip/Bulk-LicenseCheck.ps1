param($FilePath)
$users=Get-Content $FilePath
foreach($u in $users){Get-MgUserLicenseDetail -UserId $u}