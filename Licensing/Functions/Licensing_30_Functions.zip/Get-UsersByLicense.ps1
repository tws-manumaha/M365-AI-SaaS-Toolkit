param($SkuId)
Get-MgUser | Where {$_.AssignedLicenses.SkuId -contains $SkuId}