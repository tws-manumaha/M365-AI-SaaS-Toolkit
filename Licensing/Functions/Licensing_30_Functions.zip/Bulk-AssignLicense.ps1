
param($FilePath, $SkuId)
$users = Get-Content $FilePath
foreach ($u in $users) {
    try {
        Set-MgUserLicense -UserId $u -AddLicenses @{SkuId=$SkuId} -RemoveLicenses @()
        Write-Host "SUCCESS: $u"
    } catch {
        Write-Host "FAILED: $u"
    }
}
