param($SkuId)
Get-MgSubscribedSku | Where {$_.SkuId -eq $SkuId}